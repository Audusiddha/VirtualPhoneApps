from twilio.rest import Client

#account sid and auth token from twilio account

account_sid = "AC53a0682088e6b5fb6905dc194b13d1e9"
auth_token = "aa749583eb8190085ccdbef7e6a47539"
client = Client(account_sid, auth_token)


message = client.messages.create(body="Hello Everybody!!!",to="+919689408000",from_="+13853964187")  #to: sender phone number
#text message
print
message.sid
