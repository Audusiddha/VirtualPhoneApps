from twilio.rest import Client

#account sid and auth token from twilio account

account_sid = "AC53a0682088e6b5fb6905dc194b13d1e9"
auth_token = "aa749583eb8190085ccdbef7e6a47539"


client = Client(account_sid, auth_token)

call = client.calls.create(to="+919689408000",from_="+919689408000",url="https://sites.google.com/site/infotricks1on1/home/SampleAudio_0.5mb.mp3?attredirects=0&d=1.mp3")
#to: sender phone number  from:  own twilio number                          
#call for voice call outgoing

#print (message.sid)
#print (message2.sid)
print(call.sid)


#verified on jio,airtel,vodafone
