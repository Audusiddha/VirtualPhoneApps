import sys
import os
from twilio.rest import Client
from PyQt5 import QtCore, QtGui, QtWidgets
import phonebook_non_exec
import addcontact_app
from addcontact_app import addcontact_class
from PyQt5.QtWidgets import QFileDialog, QTableWidgetItem, QTableWidget, QMessageBox
import csv




class Phonebook_class(phonebook_non_exec.Ui_Dialog, QtWidgets.QDialog):

    audios_list = []

    def __init__(self):
        super(Phonebook_class, self).__init__()
        self.setupUi(self)



        self.table_contacts.setHorizontalHeaderLabels(['Name','Phone No.','Email ID','Address','DOB'])
        self.table_contacts.resizeColumnsToContents()
        self.table_contacts.horizontalHeader().setDefaultSectionSize(150)
        self.table_contacts.verticalHeader().setVisible(False)
        self.table_contacts.horizontalHeader().setFixedHeight(45)
        self.table_contacts.horizontalHeader().setStyleSheet("font: 75 13pt \"Comic Sans MS\";\n")

        if self.tabWidget.currentWidget() == self.tab_contacts:
            print("Contacts tab is active by default")
            self.open_sheet()

        self.audios_list = ['Congratulations','Good Morning','Good Night','Happy Birthday','Merry Christmas','Thank You']
        self.list_vmsg_audios.addItems(self.audios_list)
        self.list_vmsg_audios.setDisabled(True)

        self.list_vmsg_contacts.itemClicked.connect(self.list_contacts_selected)
        self.list_vmsg_audios.itemClicked.connect(self.list_audio_selected)
      
        self.tabWidget.currentChanged.connect(self.tab_changed)
        self.btn_add_contact.clicked.connect(self.addContact)
        self.btn_backup.clicked.connect(self.Backup_Contacts)
        self.btn_send_vmsg.clicked.connect(self.send_voicemsg)
    

    def tab_changed(self):


        if self.tabWidget.currentWidget() == self.tab_contacts:
            print("contacts tab is active")
            self.open_sheet()


        if self.tabWidget.currentWidget() == self.tab_voicemsg:
            print("voice message tab is active")
            self.open_voicelist()


    def send_voicemsg(self):

        vmsg_recipient = "+91" + str(self.phonenumber)
        print(vmsg_recipient)

        '''Provide proper account details from twilio.com after creating an account'''

        account_sid = "AC53a0682088e6b5fb6905dc194b13d1e9"
        auth_token = "aa749583eb8190085ccdbef7e6a47539"
        # alternate phone number = "+3203320575"

        client = Client(account_sid, auth_token)

        call = client.calls.create(to= vmsg_recipient, from_="+919689408000", url= self.URL)
        print(call.sid)
        self.list_vmsg_audios.setDisabled(True)


    def list_contacts_selected(self):
        self.list_vmsg_contacts.setEnabled(True)
        self.list_vmsg_contacts.currentItem().setSelected(True)


        a = self.list_vmsg_contacts.currentItem().text()


        self.selected_row = self.list_vmsg_contacts.currentRow()
        self.phonenumber = self.table_contacts.item(self.selected_row, 1).text()
        self.list_vmsg_audios.setDisabled(False)


        print(a, self.selected_row)
        print(self.phonenumber)




    def list_audio_selected(self):
        audioSelected = self.list_vmsg_audios.currentItem().text()
        row_audioSelected = self.list_vmsg_audios.currentRow()

        if row_audioSelected == 0:
            self.URL = "https://drive.google.com/u/0/uc?id=19jTXaQPfGHpX_tjboUC5PsOr12aMZ7HO&export=download"
        elif row_audioSelected == 1:
            self.URL = "https://drive.google.com/u/0/uc?id=1jQ3xd1AndbSwJa0RDRs59_Xzt8r74guT&export=download"
        elif row_audioSelected == 2:
            self.URL = "https://drive.google.com/u/0/uc?id=1aijcfhWlk4YT35mr24n4j12YEDGVViGe&export=download"
        elif row_audioSelected == 3:
            self.URL = "https://drive.google.com/u/0/uc?id=1SxzM6P6HIuCBgkhZp_9l4boXUlFrwTi3&export=download"
        elif row_audioSelected == 4:
            self.URL = "https://drive.google.com/u/0/uc?id=1AAYH2Cpn5aXENuf8m5VL54TL-4A3-D9d&export=download"
        else:
            self.URL = "https://drive.google.com/u/0/uc?id=1eWBy4x_44Z81pvQUDXLKMqQCFVSu0gJD&export=download"

        print(audioSelected, row_audioSelected)


    


    def open_sheet(self):
        #self.check_change = False
        path = ('./contacts.csv', 'CSV(*.csv)')
        print(path)
        if path[0] != '':
            with open(path[0], newline='') as csv_file:
                self.table_contacts.setRowCount(0)
                self.table_contacts.setColumnCount(5)
                my_file = csv.reader(csv_file, delimiter=',', quotechar='|')
                for row_data in my_file:
                    row = self.table_contacts.rowCount()
                    self.table_contacts.insertRow(row)
                    if len(row_data) > 10:
                        self.table_contacts.setColumnCount(len(row_data))
                    for column, stuff in enumerate(row_data):
                        item = QTableWidgetItem(stuff)
                        self.table_contacts.setItem(row, column, item)
        #self.check_change = True
        print(self.table_contacts.rowCount())

    def addContact(self):
        print("add contact clicked")
        QtCore.QCoreApplication.processEvents()
        os.system('python addcontact_app.py')
        # self.window = QtWidgets.QDialog()
        # self.ui = addcontact_class()
        # self.ui.setupUi(self.window)
        # self.window.show()
        #phonebook_obj.hide()

    def Backup_Contacts(self):

        print("backup button clicked")
        path = QFileDialog.getSaveFileName(self, 'Backup Contacts', os.getenv('HOME'), 'CSV(*.csv)')
        if path[0] != '':
            with open(path[0], 'w', newline='') as csv_file:
                writer = csv.writer(csv_file, dialect='excel')
                for row in range(self.table_contacts.rowCount()):
                    row_data = []
                    for column in range(self.table_contacts.columnCount()):
                        item = self.table_contacts.item(row, column)
                        if item is not None:
                            row_data.append(item.text())
                        else:
                            row_data.append('')
                    writer.writerow(row_data)


        print("all operations successful")

    def open_voicelist(self):
        print("Entered function")
        self.list_vmsg_contacts.clear()
        for vmsgCon_row in range(self.table_contacts.rowCount()):
            self.list_vmsg_contacts.addItem(self.table_contacts.item(vmsgCon_row, 0).text())

if __name__ == '__main__':
    qapp = QtWidgets.QApplication(sys.argv)
    qapp.setStyle(QtWidgets.QStyleFactory.create('Fusion'))
    phonebook_obj = Phonebook_class()
    phonebook_obj.show()
    qapp.exec_()
