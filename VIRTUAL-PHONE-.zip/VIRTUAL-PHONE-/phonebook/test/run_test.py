#import sys
#import os

#os.system('python phonebook.py')
#execfile('phonebook.py')
exec(open('phonebook_ui.py').read())
